package com.comerciosa.gestaocontatos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaocontatosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestaocontatosApplication.class, args);
	}

}
